<?php
$themeName = 'Social Network';

$themeFolder = 'social-network';

$themeAuthor = 'UOUApps';

$themeAuthorUrl = 'mailto:mahmudul96@gmail.com';

$themeVirsion = '1.0';

$themeImg = $wo['config']['site_url'] . '/themes/social-network/social-network.png';
?>