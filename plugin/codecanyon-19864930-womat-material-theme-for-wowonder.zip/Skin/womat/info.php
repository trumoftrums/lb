<?php
$themeName = 'WoMat';

$themeFolder = 'womat';

$themeAuthor = 'kulvir97';

$themeAuthorUrl = 'http://kulvir97.com/';

$themeVirsion = '1.1.4';

$themeImg = $themeFolder . '/themeLogo.png';
?>